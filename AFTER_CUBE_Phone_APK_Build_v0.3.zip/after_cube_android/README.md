# AFTER CUBE — Android starter prototype (v0.2)

## Included
- Dark purple/cyan home screen
- Basic editor screen and timeline layout
- Android document picker for video/audio selection
- Video preview using Android VideoView
- Add/remove placeholder timeline layers

## Not implemented yet
- Real multi-clip editing, drag-to-arrange, trimming/splitting
- Persistent project save/reopen
- Keyframes, graph editor, effects, transitions
- Audio playback/mixing and final video rendering/export

## Run
1. Open this folder in Android Studio.
2. Wait for Gradle sync.
3. Run the `app` configuration on an Android emulator or device (Android 8.0+).
