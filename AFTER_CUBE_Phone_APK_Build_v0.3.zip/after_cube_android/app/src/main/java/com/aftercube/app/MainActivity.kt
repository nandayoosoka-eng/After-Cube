package com.aftercube.app

import android.net.Uri
import android.os.Bundle
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val Background = Color(0xFF090A10)
private val Panel = Color(0xFF171925)
private val Purple = Color(0xFF9B6CFF)
private val Cyan = Color(0xFF55D7E8)
private val Muted = Color(0xFF9295A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AfterCubeApp() }
    }
}

@Composable
fun AfterCubeApp() {
    var showEditor by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Background, surface = Panel, primary = Purple,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Background) {
            if (showEditor) EditorScreen(onBack = { showEditor = false })
            else HomeScreen(
                selectedTab = selectedTab,
                onTab = { selectedTab = it },
                onNewProject = { showEditor = true },
                onOpenProject = { showEditor = true }
            )
        }
    }
}

@Composable
fun HomeScreen(
    selectedTab: String,
    onTab: (String) -> Unit,
    onNewProject: () -> Unit,
    onOpenProject: () -> Unit
) {
    val projects = listOf("Anime edit project", "New motion design", "Untitled project")
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(26.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("AFTER", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                Text("CUBE", color = Purple, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
            }
            Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Purple, Cyan)), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text("AC", color = Background, fontWeight = FontWeight.Black)
            }
        }
        Spacer(Modifier.height(28.dp))
        Text("Create something amazing", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Your motion editing studio", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))
        Card(onClick = onNewProject, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF30204E), Color(0xFF172B3A)))).padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("NEW PROJECT", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(7.dp))
                    Text("Start editing", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("Import a video and build your edit", color = Color(0xFFD0D1DA), fontSize = 12.sp)
                }
                Icon(Icons.Default.Add, contentDescription = "New project", tint = Color.White, modifier = Modifier.size(34.dp))
            }
        }
        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (selectedTab == "Projects") "Your projects" else "Recent projects", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("SEE ALL", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
            itemsIndexed(projects) { _, project ->
                Card(onClick = onOpenProject, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).background(Color(0xFF29223D), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("▶", color = Purple, fontSize = 20.sp) }
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text(project, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("Starter project • Tap to open", color = Muted, fontSize = 12.sp)
                        }
                        Text("•••", color = Muted)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalArrangement = Arrangement.SpaceAround) {
            NavItem("Home", selectedTab == "Home", Icons.Default.Home) { onTab("Home") }
            NavItem("Projects", selectedTab == "Projects", Icons.Default.FolderOpen) { onTab("Projects") }
            NavItem("Settings", selectedTab == "Settings", Icons.Default.Settings) { onTab("Settings") }
        }
    }
}

@Composable
fun NavItem(label: String, selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 12.dp)) {
        Icon(icon, contentDescription = label, tint = if (selected) Purple else Muted)
        Text(label, color = if (selected) Purple else Muted, fontSize = 11.sp)
    }
}

@Composable
fun EditorScreen(onBack: () -> Unit) {
    var selectedTool by remember { mutableStateOf("Layers") }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Choose a video to start your edit") }
    val layers = remember { mutableStateListOf("Video 1") }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            videoUri = uri
            if (layers.none { it.startsWith("Video") }) layers.add(0, "Video 1")
            status = "Video imported successfully"
        }
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("‹", color = Color.White, fontSize = 32.sp, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("New Project", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Portrait • 30 FPS", color = Muted, fontSize = 11.sp)
            }
            Text("EXPORT", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().weight(0.95f).background(Color(0xFF141622), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            if (videoUri != null) {
                AndroidView(
                    factory = { context -> VideoView(context).apply { setVideoURI(videoUri); setOnPreparedListener { it.isLooping = true; start() } } },
                    update = { view -> if (view.tag != videoUri) { view.tag = videoUri; view.setVideoURI(videoUri); view.setOnPreparedListener { it.isLooping = true; it.start() } } },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("▶", color = Purple, fontSize = 38.sp)
                    Text("Preview window", color = Muted, fontSize = 13.sp)
                    Text("Import a video to preview it here", color = Color(0xFF686C80), fontSize = 11.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(status, color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(7.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("00:00:00", color = Cyan, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("＋ Add layer", color = Purple, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable {
                val next = layers.size + 1
                layers.add("Text $next")
                selectedTool = "Layers"
            })
        }
        Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth().weight(1f).background(Panel, RoundedCornerShape(16.dp)).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("TIMELINE", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.weight(1f))
                Text("＋ VIDEO", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { videoPicker.launch("video/*") })
                Spacer(Modifier.width(12.dp))
                Text("＋ AUDIO", color = Purple, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { videoPicker.launch("audio/*") })
            }
            Spacer(Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(layers) { index, name ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(name, color = Color.White, fontSize = 11.sp, modifier = Modifier.width(65.dp))
                        Box(Modifier.weight(1f).height(30.dp).background(
                            when {
                                name.startsWith("Video") -> Color(0xFF3B2A62)
                                name.startsWith("Audio") -> Color(0xFF4A3444)
                                else -> Color(0xFF17404B)
                            }, RoundedCornerShape(6.dp)
                        ), contentAlignment = Alignment.CenterStart) {
                            Text(if (name.startsWith("Video") && videoUri != null) "  Imported clip" else "  ${name} layer", color = Color.White, fontSize = 10.sp)
                        }
                        Text("×", color = Muted, modifier = Modifier.clickable { if (layers.size > 1) layers.removeAt(index) }.padding(start = 8.dp))
                    }
                }
            }
            Spacer(Modifier.height(5.dp))
            Text("Basic timeline preview • clip trimming and keyframes are next", color = Muted, fontSize = 9.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("Layers", "Effects", "Keyframe", "Text", "Audio").forEach { tool ->
                Text(tool, color = if (selectedTool == tool) Cyan else Muted, fontSize = 11.sp,
                    fontWeight = if (selectedTool == tool) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.clickable { selectedTool = tool }.padding(vertical = 8.dp))
            }
        }
        Text(
            when (selectedTool) {
                "Layers" -> "Add video or audio from the timeline buttons"
                "Effects" -> "Effects panel is planned for the next build"
                "Keyframe" -> "Keyframe animation is coming next"
                "Text" -> "Text layer controls are coming next"
                else -> "Audio controls are coming next"
            },
            color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}
